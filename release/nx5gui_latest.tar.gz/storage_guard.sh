#!/bin/sh
# Bounded runtime logs; only installer-marked, confirmed backups may be pruned.
set -eu
ROOT=${NX5_STORAGE_ROOT:-/data}
case "$ROOT" in /*) ;; *) exit 2;; esac
[ "$ROOT" != / ] && [ -d "$ROOT" ] && [ ! -L "$ROOT" ] || exit 2
MODE=${1:---once}
rotate_logs() {
 for entry in nx5gui_live.log:4194304 btproxy.log:1048576 zbbridge.log:524288 wifi_health.log:262144 kmsg.log:2097152 bx2.log:1048576; do
  name=${entry%:*}; limit=${entry#*:}; file="$ROOT/$name"
  [ -f "$file" ] && [ ! -L "$file" ] || continue
  size=$(wc -c < "$file")
  [ "$size" -gt "$limit" ] || continue
  tmp=$(mktemp "${TMPDIR:-/tmp}/nx5-log-tail.XXXXXX") || continue
  if tail -c 131072 "$file" > "$tmp"; then
   # Keep the inode: GUI/daemon stdout may still hold this file open.
   cat "$tmp" > "$file" || :
  fi
  rm -f "$tmp"
 done
}
boot_cleanup() {
 boot=$(cat "${NX5_STORAGE_BOOT_ID_FILE:-/proc/sys/kernel/random/boot_id}" 2>/dev/null || :)
 [ -n "$boot" ] || return 0
 dir="$ROOT/nx5_ota"
 if [ -d "$dir" ] && [ ! -L "$dir" ] && [ ! -f "$dir/pending" ] && [ -f "$dir/owner-boot" ] && [ ! -L "$dir/owner-boot" ]; then
  owner=$(cat "$dir/owner-boot")
  case "$owner" in ''|*[!0-9a-f-]*) ;; *)
   if [ "$owner" != "$boot" ]; then rm -f "$dir/ota.tar" "$dir/ota_try.tar" "$dir/ota_upload.envelope" "$dir/owner-boot";fi;;
  esac
 fi
 for dir in "$ROOT"/.nx5-full-install.*; do
  [ -d "$dir" ] && [ ! -L "$dir" ] && [ -f "$dir/.nx5-stage-owner" ] && [ ! -L "$dir/.nx5-stage-owner" ] || continue
  [ ! -e "$dir/.nx5-stage-recovery-needed" ] || continue
  read -r owner_boot owner_pid < "$dir/.nx5-stage-owner" || continue
  case "$owner_boot" in ''|*[!0-9a-f-]*) continue;; esac
  case "$owner_pid" in ''|*[!0-9]*) continue;; esac
  # Only a different boot proves this extraction is no longer live.
  [ "$owner_boot" = "$boot" ] || rm -rf "$dir"
 done
}
confirmed_cleanup() {
 current=${2:-}
 [ ! -f "$ROOT/nx5_ota/pending" ] || return 0
 case "$current" in "$ROOT"/deployment-backups/*) ;; *) return 2;; esac
 name=${current##*/};[ "$current" = "$ROOT/deployment-backups/$name" ] || return 2;case "$name" in ''|*[!0-9-]*) return 2;; esac
 [ ! -L "$ROOT/deployment-backups" ] && [ -d "$current" ] && [ ! -L "$current" ] || return 2
 [ -f "$current/managed-v1" ] && [ ! -L "$current/managed-v1" ] || return 0
 [ ! -L "$current/confirmed" ] && [ -f "$current/target-version" ] && [ ! -L "$current/target-version" ] && [ -f "$current/source-version" ] && [ ! -L "$current/source-version" ] || return 2
 [ -f "$current/changed-files" ] && [ ! -L "$current/changed-files" ] || return 2
 target=$(cat "$current/target-version")
 from=$(cat "$current/source-version")
 : > "$current/confirmed"
 # Keep this rollback plus one older different-version rollback on same-version reinstall.
 keep_old=''
 if [ "$from" = "$target" ]; then
  for dir in "$ROOT"/deployment-backups/*; do
   [ "$dir" != "$current" ] && [ -d "$dir" ] && [ ! -L "$dir" ] && [ -f "$dir/managed-v1" ] && [ -f "$dir/confirmed" ] || continue
   old=$(cat "$dir/source-version" 2>/dev/null || :)
   if [ -n "$old" ] && [ "$old" != "$target" ]; then keep_old=$dir;fi
  done
 fi
 for dir in "$ROOT"/deployment-backups/*; do
  [ "$dir" != "$current" ] && [ "$dir" != "$keep_old" ] || continue
  name=${dir##*/};case "$name" in ''|*[!0-9-]*) continue;; esac
  [ -d "$dir" ] && [ ! -L "$dir" ] && [ -f "$dir/managed-v1" ] && [ ! -L "$dir/managed-v1" ] && [ -f "$dir/confirmed" ] && [ ! -L "$dir/confirmed" ] || continue
  rm -rf "$dir"
 done
}
case "$MODE" in
 --once) rotate_logs;;
 --boot) boot_cleanup;rotate_logs;;
 --confirmed) confirmed_cleanup "$@";;
 --daemon)
  lock=${NX5_STORAGE_LOCK:-/tmp/nx5-storage-guard.lock}
  if ! mkdir "$lock" 2>/dev/null; then
   pid=$(cat "$lock/pid" 2>/dev/null || :)
   case "$pid" in ''|*[!0-9]*) ;; *) if kill -0 "$pid" 2>/dev/null; then exit 0;fi;; esac
   rm -rf "$lock";mkdir "$lock" 2>/dev/null || exit 0
  fi
  echo $$ > "$lock/pid"
  trap 'rm -rf "$lock"' EXIT
  trap 'exit 0' INT TERM
  boot_cleanup
  while :;do rotate_logs;sleep 60;done;;
 *) exit 2;;
esac
