#!/bin/sh
# start_app.sh — NX5 开机接管脚本(v9:产测分叉直启,2026-10-26)
#
# ★v9 架构(用户发现的官方分叉点):/data/productionTest + /data/nand-1 存在时,
#   原厂 start_app.sh 走产测分支——lingdong_app.sh 整条链不跑:
#   linkdora_broker/devinfo/ult_dg/guardian 全不启动 → guardian 不存在 →
#   原厂 GUI(aciga_lvgl,由 guardian 复活)永不出现。文件在 /data 天然跨重启。
#   我们移植必要服务(broker+devinfo=WiFi/背光/gl_ioctrl),GUI 走 fymedia 直启。
#   回退 = rm /data/productionTest /data/nand-1 && reboot(回 v8 接管态)。
# 单实例:目录锁 + 心跳。旧实例被 kill -9 后心跳停止,15s 后新实例可接管。
LOCK=/tmp/start_app.lock
_now=$(date +%s)
if ! mkdir "$LOCK" 2>/dev/null; then
  _last=$(cat "$LOCK/hb" 2>/dev/null || echo 0)
  case "$_last" in ''|*[!0-9]*) _last=0;; esac
  if [ $((_now - _last)) -lt 20 ]; then
    echo "[start_app] another instance active, exit"
    exit 0
  fi
  rm -rf "$LOCK"; mkdir "$LOCK" 2>/dev/null || exit 0
fi
echo "$_now" > "$LOCK/hb"
hb() { date +%s > "$LOCK/hb" 2>/dev/null; }

(
    # ---- 批次环境 ----
    [ -f /data/bin/nx5_env.sh ] && . /data/bin/nx5_env.sh
    [ ! -x /data/storage_guard.sh ] || ( nohup sh /data/storage_guard.sh --daemon >/dev/null 2>&1 & )
    # HA 大包链路看护:eth0 收 ~13KB 后 RX 停摆(驱动缺陷),会导致 /api/states
    # (1.1MB)永远拉不完→实体池只剩米家、所有卡片未获取状态。等网络稳定后
    # 每 5 分钟体检,异常时复位 eth0 或把 HA /32 路由切到 wlan0。
    [ ! -x /data/bin/ha_link_guard.sh ] || ( sleep 45; exec sh /data/bin/ha_link_guard.sh ) >/dev/null 2>&1 &
    [ ! -f /data/nx5_ota/pending ] || ( sh /data/ota_health.sh >>/data/nx5gui_live.log 2>&1 & )
    export NX5_FREE_CARD_DEFAULT_DIR="${NX5_FREE_CARD_DEFAULT_DIR:-/data/share/nx5/free_cards/domains}"

    if [ -n "$NX5_DIRECT_BOOT" ]; then
        # ============ 产测分叉直启(v9) ============
        echo "[start_app] direct-boot v9: production-fork mode"
        hb

        # 移植 lingdong_app.sh 的服务链(guardian 故意不启——它会复活原厂 GUI)
        export PATH=$PATH:/system/user/bin:/system/bin
        export LD_LIBRARY_PATH=/system/user/lib:/system/lib
        cd /system/user/bin
        if [ -x ./linkdora_broker ] && ! pidof linkdora_broker >/dev/null; then
            chmod 777 linkdora_broker
            nohup ./linkdora_broker >/dev/null 2>&1 &
            echo "[start_app] linkdora_broker started"
        fi
        sleep 1
        hb
        # WiFi 凭据保护(2026-10-26):devinfo 开机会重建 wpa_supplicant.config
        # (rm+cp useretc 模板)→已存 WiFi 丢失。启它前备份,起来后若被清则回写+重连。
        WPACONF=/data/etc/wpa_supplicant.config
        WPABAK=/data/bin/wpa_conf_backup.conf
        [ -s "$WPACONF" ] && grep -q "network={" "$WPACONF" && (umask 077; cp -f "$WPACONF" "$WPABAK.new" && mv -f "$WPABAK.new" "$WPABAK")

        if [ -x ./aciga_devinfo ] && ! pidof aciga_devinfo >/dev/null; then
            chmod 777 aciga_devinfo
            nohup ./aciga_devinfo >/dev/null 2>&1 &
            echo "[start_app] aciga_devinfo started(WiFi+背光+gl_ioctrl)"
        fi

        hb
        sleep 6   # devinfo 订阅 /devInfo 主题需要时间;GUI 过早发布初始亮度会被丢(白斑界面根因)

        # devinfo 若清了凭据:回写并 reconfigure
        if [ -s "$WPABAK" ] && grep -q "network={" "$WPABAK" && ! grep -q "network={" "$WPACONF" 2>/dev/null; then
            cp -f "$WPABAK" "$WPACONF"
            wpa_cli -i wlan0 reconfigure >/dev/null 2>&1 &
            echo "[start_app] wifi credentials restored"
        fi

        # GUI 直启(fymedia 全协议在 nx5gui 进程内)+ 常驻看护
        # 看护职责:GUI 死亡 → 立即把 PWM duty 从 ~0 拉回安全档(白斑=duty≈0 而 LCM
        # 仍亮时灯珠漏电不均,硬件特性;进程死后内核 fyfb 释放会归零 duty)→ 重启 GUI
        PWM="$(ls /sys/class/pwm/pwmchip*/pwm0/duty_cycle 2>/dev/null | head -1)"
        # 白斑防 = 两层:①emergency_bl(on_crash 内恢复 duty,信号可救的死亡)
        # ②下方 keeper 死亡检测恢复 duty(kill -9/OOM 等不可自救死亡,窗口 ≤5s)。
        # fb0 哨兵(第三层)已否决:短测通过但真实运行复现白斑+引擎损坏。
        # 日志轮转:live.log >5MB 时留尾 1MB(2026-10-26 95MB 日志塞爆 157MB /data → ENOSPC 部署截断)
        if [ -f /data/nx5gui_live.log ] && [ "$(wc -c < /data/nx5gui_live.log)" -gt 5000000 ]; then
            tail -c 1000000 /data/nx5gui_live.log > /data/nx5gui_live.tail && mv -f /data/nx5gui_live.tail /data/nx5gui_live.log
        fi
        # 堆检测(2026-10-26):163 反复静默死亡=主线程 r7(帧指针)被踩,
        # 内核 Oops(do_sys_open 垃圾指针)后喂狗断→硬件复位。MALLOC_CHECK
        # 让堆越界当场 abort 留日志指认;PERTURB 用垃圾填充 freed 块放大复现。
        export MALLOC_CHECK_=3
        export MALLOC_PERTURB_=165
        # fb0 哨兵方案 2026-10-27 实测否决:kill -9 短测 duty 恒定,但真实运行
        # 后白斑复现+显示引擎损坏(GUI 重启无法恢复)——多开 fyfb 的损坏是
        # 时序性/累积性的,短测无法暴露。白斑兜底=守护死亡检测恢复 duty(≤5s)。
        # 内核日志流式落盘(2026-10-27):开机窗口的内核 Oops 随复位丢失——
        # 流式记录器常驻,死亡瞬间现场永久保留 /data/kmsg.log(2MB 上限滚动)
        KM=0
        for p in $(ps | grep kmsglog | grep -v grep | awk '{print $1}'); do KM=1; done
        [ "${NX5_ENABLE_KMSGLOG:-0}" = "1" ] && [ "$KM" = "0" ] && [ -x /data/kmsglog.sh ] && ( setsid sh /data/kmsglog.sh >/dev/null 2>&1 & )
        [ "${NX5_ENABLE_BX2:-0}" = "1" ] && [ -x /data/bx2.sh ] && ( setsid sh /data/bx2.sh >/dev/null 2>&1 & )
        [ "${NX5_GPIO83FEED:-0}" = "1" ] && [ -x /data/g83feed.sh ] && ( setsid sh /data/g83feed.sh >/dev/null 2>&1 & )
        # 清理手工遗留的 keeper19(与内置看护双实例会各自拉 GUI,
        # 第二实例 flock 失败退出前已跑 port_disp DEINIT 拆掉第一实例的
        # 显示链 → 内核 Oops→GUI1 死→"开机+21s 重启"假象,2026-10-27 定案)
        for kp in $(ps | grep keeper19 | grep -v grep | awk '{print $1}'); do
            kill -9 $kp 2>/dev/null
        done
        TRIES=0
        while [ $TRIES -lt 3 ]; do
            cd /data
            # fix261:媒体系统 SYS 初始化——必须在 GUI 起显示【之前】做,否则
            # 厂商 VO_Enable 会 vou stop device 停掉显示链(界面全黑)。
            [ -x /data/nx5_vdec_helper ] && /data/nx5_vdec_helper --bootstrap >>/data/nx5gui_live.log 2>&1
            # fix263:硬解常驻守护(GUI 内存紧张,fork/posix_spawn 会 ENOMEM)。
            # 只等请求文件 /tmp/camreq,不占解码资源;GUI 退出它也留着。
            if [ -x /data/nx5_vdec_helper ]; then
                DP=$(cat /tmp/nx5cam_d.pid 2>/dev/null)
                if [ -z "$DP" ] || ! kill -0 "$DP" 2>/dev/null; then
                    ( nohup /data/nx5_vdec_helper --daemon >>/data/nx5gui_live.log 2>&1 & )
                fi
            fi
            # P0 音频前端:acw start_capture(mic 拾音必需);幂等,已有实例自退。
            ( sleep 20; mkdir -p /tmp/run; cd /tmp/run; touch sipservice.pid;
              LD_LIBRARY_PATH=/system/user/lib/p3_sip:/system/user/lib/p3:/system/user/lib:/system/lib
              export LD_LIBRARY_PATH
              setsid /system/user/bin/sipservice >/tmp/sip.log 2>&1 </dev/null ) &
            # 语音对讲:mode=sip 启动 Baresip + nx5sip_helper(私有 glibc),
            # 否则启动现有 WebRTC helper。两者不能同时跑(抢 /dev/acw-0)。
            if [ -f /data/nx5_conf/intercom/mode ] && grep -q '^sip' /data/nx5_conf/intercom/mode \
               && [ -x /data/nx5_conf/baresip/baresip ] && [ -x /data/nx5_conf/baresip/nx5sip_helper ]; then
                ( sleep 25; cd /data/nx5_conf/baresip; setsid /data/nx5nss/runtime/ld-linux.so.3 --library-path /data/nx5nss/runtime:/system/user/lib ./baresip -f /data/nx5_conf/baresip >/data/baresip.log 2>&1 </dev/null ) &
                ( sleep 27; cd /data/nx5_conf/baresip; setsid ./nx5sip_helper >/data/nx5sip_helper.log 2>&1 </dev/null ) &
            elif [ -x /data/nx5ic_helper ]; then
                ( sleep 25; cd /data; setsid /data/nx5ic_helper >/data/nx5ic_helper.log 2>&1 </dev/null ) &
            fi
            # 白斑终案(2026-11-10):常驻显示 Owner(nx5vo)持有 VO 会话+fb0
            # 跨 GUI 重启——GUI 死亡不触发驱动最后关闭,面板持续扫描、画面冻结,
            # GUI 拉起后无缝接管。Owner 自带监督(退避重启/连续失败压黑节流/
            # 控制口背光交接),此处只看护 Owner 本身。
            NX5_ENABLE_LOCAL_ACTIONS=1 NX5_ENABLE_LOCAL_SHELL=1 LD_LIBRARY_PATH=/data/nx5nss NX5_CIVET_BIND=0.0.0.0 NX5_CIVET_ALLOW_OPEN=1 NX5TS_DBG=1 nohup ./nx5vo ./nx5gui /data/nx5_conf/intercom/home_layout.json /dev/fb0 /dev/input/event0 >> /data/nx5gui_live.log 2>&1 &
            # 蓝牙代理:开关标志 nx5_conf/bt_on
            [ -x /data/btproxy.sh ] && [ -f /data/nx5_conf/intercom/bt_on ] && (sleep 8; /data/btproxy.sh >/dev/null 2>&1 &)
            # Zigbee 网关
            [ -x /data/zbbridge.sh ] && [ -f /data/nx5_conf/intercom/zb_on ] && (sleep 20; setsid sh /data/zbbridge.sh reset >/data/zb_reset.log 2>&1 &)
            # 看护 Owner:GUI 死亡由 Owner 秒级拉起(画面冻结,无需背光动作);
            # Owner 本身死亡→GUI 仍持有继承引用(显示链活着)→重启 Owner 接管
            STABLE=0
            while :; do
                hb
                if command -v usleep >/dev/null 2>&1; then KEP_TICK='usleep 300000'; else KEP_TICK='sleep 1'; fi
                $KEP_TICK
                OK=""
                for p in $(ps | grep nx5vo | grep -v grep | awk '{print $1}'); do
                    case "$(readlink /proc/$p/exe 2>/dev/null)" in /data/nx5vo) OK=1;; esac
                done
                if [ -n "$OK" ]; then
                    STABLE=$((STABLE+1))
                    if [ $STABLE -gt 200 ]; then TRIES=0; STABLE=0; fi   # 稳定 60s 后重置重试计数
                    continue
                fi
                STABLE=0
                [ -f /data/nx5blpub ] && cp -f /data/nx5blpub /data/bin/nx5blpub && chmod +x /data/bin/nx5blpub && rm -f /data/nx5blpub
                echo "[start_app] nx5vo died (GUI keeps display), restarting owner"
                NX5_ENABLE_LOCAL_ACTIONS=1 NX5_ENABLE_LOCAL_SHELL=1 LD_LIBRARY_PATH=/data/nx5nss NX5_CIVET_BIND=0.0.0.0 NX5_CIVET_ALLOW_OPEN=1 NX5TS_DBG=1 nohup ./nx5vo ./nx5gui /data/nx5_conf/intercom/home_layout.json /dev/fb0 /dev/input/event0 >> /data/nx5gui_live.log 2>&1 &
                break
            done
            TRIES=$((TRIES+1))
        done
        echo "[start_app] direct boot keeper exited (gui tries=$TRIES)"
        exit 0
    fi

    # ============ 常规接管模式(v6 流程) ============
    # ---- 直启:垫片 bind mount(旧方案保留但不再默认) ----
    if [ -n "$NX5_KILL_TAKEOVER" ] || [ -f /data/productionTest ]; then :; fi

    # ---- 等原厂 aciga_lvgl 出现(最多 120s) ----
    i=0
    while [ $i -lt 24 ]; do
        hb
        VP=""
        for p in $(ps | grep aciga_lvgl | grep -v grep | awk '{print $1}'); do
            case "$(readlink /proc/$p/exe 2>/dev/null)" in /system/*) VP="$VP $p";; esac
        done
        [ -n "$VP" ] && break
        sleep 5
        i=$((i+1))
    done

    # ---- 等面板点亮 ----
    j=0
    while [ $j -lt 40 ]; do
        hb
        D=$(cat /sys/class/pwm/pwmchip0/pwm0/duty_cycle 2>/dev/null)
        case "$D" in ''|0) sleep 1; j=$((j+1));; *) break;; esac
    done
    sleep 5

    # ---- kill-接管(原厂点亮使命完成,杀掉;GUI 重开 fb0 复点) ----
    if [ -n "$NX5_KILL_TAKEOVER" ]; then
        for p in $(ps | grep aciga_lvgl | grep -v grep | awk '{print $1}'); do
            case "$(readlink /proc/$p/exe 2>/dev/null)" in /system/*) kill -9 $p 2>/dev/null; echo "[start_app] kill-takeover: vendor $p killed";; esac
        done
        sleep 2
    fi

    # ---- 启动我们的 GUI + 崩溃自动重启(≤3 次) ----
    TRIES=0
    while [ $TRIES -lt 3 ]; do
        hb
        cd /data
        export PATH=$PATH:/system/bin:/system/user/bin
        export LD_LIBRARY_PATH=/system/user/lib:/system/lib
        NX5_ENABLE_LOCAL_ACTIONS=1 NX5_ENABLE_LOCAL_SHELL=1 LD_LIBRARY_PATH=/data/nx5nss NX5_CIVET_BIND=0.0.0.0 NX5_CIVET_ALLOW_OPEN=1 NX5TS_DBG=1 nohup ./nx5gui /data/nx5_conf/intercom/home_layout.json /dev/fb0 /dev/input/event0 >> /data/nx5gui_live.log 2>&1 &
        [ -x /data/btproxy.sh ] && [ -f /data/nx5_conf/intercom/bt_on ] && (sleep 8; /data/btproxy.sh >/dev/null 2>&1 &)
        [ -x /data/zbbridge.sh ] && [ -f /data/nx5_conf/intercom/zb_on ] && (sleep 20; setsid sh /data/zbbridge.sh reset >/data/zb_reset.log 2>&1 &)
        sleep 5
        STABLE=0
        k=0
        while [ $k -lt 4320 ]; do
            hb
            ALIVE=""
            for p in $(ps | grep nx5gui | grep -v grep | awk '{print $1}'); do
                case "$(readlink /proc/$p/exe 2>/dev/null)" in /data/*) ALIVE=1;; esac
            done
            [ -z "$ALIVE" ] && break
            if [ -n "$NX5_KILL_TAKEOVER" ] && [ $((k % 12)) -eq 0 ]; then
                for p in $(ps | grep aciga_lvgl | grep -v grep | awk '{print $1}'); do
                    case "$(readlink /proc/$p/exe 2>/dev/null)" in /system/*) kill -9 $p 2>/dev/null;; esac
                done
                grep -q "shim_lvgl" /proc/mounts 2>/dev/null || \
                    mount --bind /data/shim_lvgl /system/user/bin/aciga_lvgl 2>/dev/null
            fi
            sleep 5
            k=$((k+1))
        done
        if [ -n "$NX5_DIRECT_BOOT" ]; then
            TRIES=$((TRIES+1)); continue
        fi
        for p in $(ps | grep aciga_lvgl | grep -v grep | awk '{print $1}'); do
            kill -CONT $p 2>/dev/null
        done
        sleep 15
        for p in $(ps | grep aciga_lvgl | grep -v grep | awk '{print $1}'); do
            case "$(readlink /proc/$p/exe 2>/dev/null)" in /system/*) kill -STOP $p 2>/dev/null;; esac
        done
        TRIES=$((TRIES+1))
    done
    for p in $(ps | grep aciga_lvgl | grep -v grep | awk '{print $1}'); do
        kill -CONT $p 2>/dev/null
    done
) &
exit 0
