#!/bin/sh
# start_app.sh — NX5 开机接管脚本(v9:产测分叉直启,2026-10-26)
#
# ★v9 架构(用户发现的官方分叉点):/data/productionTest + /data/nand-1 存在时,
#   原厂 start_app.sh 走产测分支——lingdong_app.sh 整条链不跑:
#   linkdora_broker/devinfo/ult_dg/guardian 全不启动 → guardian 不存在 →
#   原厂 GUI(aciga_lvgl,由 guardian 复活)永不出现。文件在 /data 天然跨重启。
#   我们移植必要服务(broker+devinfo=WiFi/背光/gl_ioctrl),GUI 走 fymedia 直启。
#   回退 = rm /data/productionTest /data/nand-1 && reboot(回 v8 接管态)。
# 单实例:目录锁 + 心跳。旧实例被 kill -9 后心跳停止,15s 后新实例可接管。
LOCK=/tmp/start_app.lock
# A live keeper wins regardless of wall-clock corrections or delayed I/O.
# The background keeper records its own /proc PID, not the exited shell's $$.
if [ -f "$LOCK/pid" ]; then
  read _keeper < "$LOCK/pid"
  case "$_keeper" in ''|*[!0-9]*) ;; *)
    if kill -0 "$_keeper" 2>/dev/null; then
      case "$(tr '\000' ' ' < /proc/$_keeper/cmdline 2>/dev/null)" in
        *start_app.sh*) echo "[start_app] live keeper $_keeper, exit";exit 0;;
      esac
    fi;;
  esac
fi
_now=$(date +%s)
if ! mkdir "$LOCK" 2>/dev/null; then
  _last=$(cat "$LOCK/hb" 2>/dev/null || echo 0)
  case "$_last" in ''|*[!0-9]*) _last=0;; esac
  if [ $((_now - _last)) -lt 20 ]; then
    echo "[start_app] another instance active, exit"
    exit 0
  fi
  rm -rf "$LOCK"; mkdir "$LOCK" 2>/dev/null || exit 0
fi
echo "$_now" > "$LOCK/hb"
hb() { date +%s > "$LOCK/hb" 2>/dev/null; }

(
    read _keeper_pid _rest < /proc/self/stat
    echo "$_keeper_pid" > "$LOCK/pid"
    # ---- 批次环境 ----
    [ -f /data/bin/nx5_env.sh ] && . /data/bin/nx5_env.sh
    [ ! -x /data/storage_guard.sh ] || ( nohup sh /data/storage_guard.sh --daemon >/dev/null 2>&1 & )
    # HA 大包链路看护:eth0 收 ~13KB 后 RX 停摆(驱动缺陷),会导致 /api/states
    # (1.1MB)永远拉不完→实体池只剩米家、所有卡片未获取状态。等网络稳定后
    # 每 5 分钟体检,异常时复位 eth0 或把 HA /32 路由切到 wlan0。
    # 单实例:每次 GUI 重启不再叠加第二个看护(重复实例会用旧代码继续写旧日志文件)
[ ! -x /data/bin/ha_link_guard.sh ] || ( sleep 45; [ "$(ps | grep -c '[h]a_link_guard.sh')" -eq 0 ] && exec sh /data/bin/ha_link_guard.sh ) >/dev/null 2>&1 &
    [ ! -f /data/nx5_ota/pending ] || ( sh /data/ota_health.sh >>/data/nx5gui_live.log 2>&1 & )
    export NX5_FREE_CARD_DEFAULT_DIR="${NX5_FREE_CARD_DEFAULT_DIR:-/data/share/nx5/free_cards/domains}"
    # 开机提速(2026-11-27):趁等 broker/devinfo/显示就绪的这几秒,把 GUI 启动要读的文件整份读进
    # 内存缓存。12.8MB 的静态二进制在 JFFS2 上是按需换页的,冷读约 3MB/s:原先 exec 后的几秒里
    # 一大半耗在换页上(fork→main 0.4~1.8 秒,界面初始化 1.1 秒);引擎引导也在冷读约 2.4MB 的
    # 配置(米家配置/能力表/实体池快照/规则)。这里后台顺序读一遍(nice 19),GUI 真正用到时缺页
    # 全部命中缓存:206 实测 fork→main 9 毫秒、界面初始化 95 毫秒。只读不写,不磨损闪存;缓存是
    # 干净页,内存紧张时内核可直接回收。某个文件不存在或读失败都跳过,不影响后面的启动。
    # 完成时刻记在 /tmp/nx5-prewarm.uptime(排查用)。
    (
        for _f in /data/nx5gui /data/nx5_conf/intercom/mijia.json /data/nx5_conf/intercom/mijia_caps.json \
                  /data/nx5_conf/intercom/ha_pool_cache.bin /data/specs/rules.json; do
            [ -f "$_f" ] && nice -n 19 dd if="$_f" of=/dev/null bs=65536 2>/dev/null
        done
        cat /proc/uptime > /tmp/nx5-prewarm.uptime 2>/dev/null
    ) >/dev/null 2>&1 &

    if [ -n "$NX5_DIRECT_BOOT" ]; then
        # ============ 产测分叉直启(v9) ============
        echo "[start_app] direct-boot v9: production-fork mode"
        hb

        # 移植 lingdong_app.sh 的服务链(guardian 故意不启——它会复活原厂 GUI)
        export PATH=$PATH:/system/user/bin:/system/bin
        export LD_LIBRARY_PATH=/system/user/lib:/system/lib
        cd /system/user/bin
        if [ -x ./linkdora_broker ] && ! pidof linkdora_broker >/dev/null; then
            chmod 777 linkdora_broker
            nohup ./linkdora_broker >/dev/null 2>&1 &
            echo "[start_app] linkdora_broker started"
        fi
        sleep 1
        hb
        # WiFi 凭据保护(2026-10-26):devinfo 开机会重建 wpa_supplicant.config
        # (rm+cp useretc 模板)→已存 WiFi 丢失。启它前备份,起来后若被清则回写+重连。
        WPACONF=/data/etc/wpa_supplicant.config
        WPABAK=/data/bin/wpa_conf_backup.conf
        [ -s "$WPACONF" ] && grep -q "network={" "$WPACONF" && (umask 077; cp -f "$WPACONF" "$WPABAK.new" && mv -f "$WPABAK.new" "$WPABAK")

        if [ -x ./aciga_devinfo ] && ! pidof aciga_devinfo >/dev/null; then
            chmod 777 aciga_devinfo
            nohup ./aciga_devinfo >/dev/null 2>&1 &
            echo "[start_app] aciga_devinfo started(WiFi+背光+gl_ioctrl)"
        fi

        hb
        # devinfo 就绪等待(2026-11-26 改):原来是写死的 sleep 6。实测(206,开机探针)
        # devinfo 12.7s 起来、15.5s 连上 broker(@linkdora_brok 出现 St=03 的对端),
        # 而 bootstrap 在 19.8s——连接建立后还白等了 4.3 秒,期间 Logo 一直可显示。
        # 现在:轮询"已连接对端数 ≥1",连上后再留 1 秒余量(覆盖 /devInfo 主题订阅);
        # 最多仍等原来的 6 秒(判据万一失灵不至于比以前慢)。
        # 背光命令经 devinfo 转发,GUI/Owner 过早发布会被丢——所以连接是继续的必要条件。
        _dw=0
        while [ $_dw -lt 60 ]; do
            _dc=$(grep linkdora_brok /proc/net/unix 2>/dev/null | grep -c ' 0001 03 ')
            [ "${_dc:-0}" -ge 1 ] && break
            usleep 100000 2>/dev/null || sleep 1
            _dw=$((_dw+1))
        done
        usleep 1000000 2>/dev/null || sleep 1
        echo "[start_app] devinfo ready after ~$((${_dw}/10)).$((_dw%10))s connected (poll)" >> /data/nx5gui_live.log

        # devinfo 若清了凭据:回写并 reconfigure。
        # ★这个检查不依赖上面的等待时长:放到后台再盯 8 秒反复查——devinfo 重建
        #   wpa_supplicant.config 的时机不保证在连接 broker 之前,只查一次可能漏
        #   (丢了已存 WiFi)。显示启动不必等它。
        (
            _n=0
            while [ $_n -lt 16 ]; do
                if [ -s "$WPABAK" ] && grep -q "network={" "$WPABAK" && ! grep -q "network={" "$WPACONF" 2>/dev/null; then
                    cp -f "$WPABAK" "$WPACONF"
                    wpa_cli -i wlan0 reconfigure >/dev/null 2>&1 &
                    echo "[start_app] wifi credentials restored"
                    break
                fi
                sleep 0.5 2>/dev/null || sleep 1
                _n=$((_n+1))
            done
        ) &

        # GUI 直启(fymedia 全协议在 nx5gui 进程内)+ 常驻看护
        # 看护职责:GUI 死亡 → 立即把 PWM duty 从 ~0 拉回安全档(白斑=duty≈0 而 LCM
        # 仍亮时灯珠漏电不均,硬件特性;进程死后内核 fyfb 释放会归零 duty)→ 重启 GUI
        PWM="$(ls /sys/class/pwm/pwmchip*/pwm0/duty_cycle 2>/dev/null | head -1)"
        # 白斑防 = 两层:①emergency_bl(on_crash 内恢复 duty,信号可救的死亡)
        # ②下方 keeper 死亡检测恢复 duty(kill -9/OOM 等不可自救死亡,窗口 ≤5s)。
        # fb0 哨兵(第三层)已否决:短测通过但真实运行复现白斑+引擎损坏。
        # 日志轮转:live.log >5MB 时留尾 1MB(2026-10-26 95MB 日志塞爆 157MB /data → ENOSPC 部署截断)
        if [ -f /data/nx5gui_live.log ] && [ "$(wc -c < /data/nx5gui_live.log)" -gt 5000000 ]; then
            tail -c 1000000 /data/nx5gui_live.log > /data/nx5gui_live.tail && mv -f /data/nx5gui_live.tail /data/nx5gui_live.log
        fi
        # 堆检测(2026-10-26):163 反复静默死亡=主线程 r7(帧指针)被踩,
        # 内核 Oops(do_sys_open 垃圾指针)后喂狗断→硬件复位。MALLOC_CHECK
        # 让堆越界当场 abort 留日志指认;PERTURB 用垃圾填充 freed 块放大复现。
        export MALLOC_CHECK_=3
        export MALLOC_PERTURB_=165
        # fb0 哨兵方案 2026-10-27 实测否决:kill -9 短测 duty 恒定,但真实运行
        # 后白斑复现+显示引擎损坏(GUI 重启无法恢复)——多开 fyfb 的损坏是
        # 时序性/累积性的,短测无法暴露。白斑兜底=守护死亡检测恢复 duty(≤5s)。
        # 内核日志流式落盘(2026-10-27):开机窗口的内核 Oops 随复位丢失——
        # 流式记录器常驻,死亡瞬间现场永久保留 /data/kmsg.log(2MB 上限滚动)
        KM=0
        for p in $(ps | grep kmsglog | grep -v grep | awk '{print $1}'); do KM=1; done
        [ "${NX5_ENABLE_KMSGLOG:-0}" = "1" ] && [ "$KM" = "0" ] && [ -x /data/kmsglog.sh ] && ( setsid sh /data/kmsglog.sh >/dev/null 2>&1 & )
        [ "${NX5_ENABLE_BX2:-0}" = "1" ] && [ -x /data/bx2.sh ] && ( setsid sh /data/bx2.sh >/dev/null 2>&1 & )
        [ "${NX5_GPIO83FEED:-0}" = "1" ] && [ -x /data/g83feed.sh ] && ( setsid sh /data/g83feed.sh >/dev/null 2>&1 & )
        # 清理手工遗留的 keeper19(与内置看护双实例会各自拉 GUI,
        # 第二实例 flock 失败退出前已跑 port_disp DEINIT 拆掉第一实例的
        # 显示链 → 内核 Oops→GUI1 死→"开机+21s 重启"假象,2026-10-27 定案)
        for kp in $(ps | grep keeper19 | grep -v grep | awk '{print $1}'); do
            kill -9 $kp 2>/dev/null
        done
        TRIES=0
        while [ $TRIES -lt 3 ]; do
            cd /data
            # 统一日志服务(2026-11-25 日志治理 P1):单写入者,有界内存环 + 关键记录
            # 分类落盘。必须早于 GUI/媒体/语音服务启动,失败不影响任何功能。
            mkdir -p /tmp/nx5/run /tmp/nx5/log /data/log/nx5 2>/dev/null
            if [ -x /data/nx5_logd ]; then
                setsid /data/nx5_logd >/dev/null 2>&1 </dev/null &
                echo "start_app: nx5_logd started" >&2
            fi
            # tmpfs 兜底(2026-11-25 OOM 事件):历史 sip.log/临时日志曾灌满 /tmp
            # (44.8M)导致内核 OOM 杀 GUI。启动前把已知大临时日志截断。
            for f in /tmp/sip.log /tmp/ic_flight.log; do
                [ -f "$f" ] || continue
                SZ=$(wc -c < "$f" 2>/dev/null || echo 0)
                [ "${SZ:-0}" -gt 1048576 ] && : > "$f"
            done
            # ★原厂 sipservice(原厂 SIP 服务,持 /dev/sys + /dev/vo):默认【不】启动。
            # 对讲音频不依赖它——Baresip 的 nx5audio 模块直接链接原厂 libAudioCore,自建
            # AudioUdpServer 完成采集/播放(docs/DESIGN_AUDIO_RE.md;无此进程通话正常的
            # 整机重启验证见 docs/DESIGN_INTERCOM_SIP.md)。而它一启动就重置媒体系统
            # (VO disable → SYS_Exit → SYS_Init → VO enable),退出时把媒体系统整个拆掉:
            # 2.0.42~2.0.51 把它放在 GUI 之后 20s 启动,就是"开机亮屏约 20s 后黑屏
            # (背光亮、进程健在)"的根因(2026-11-25 dmesg 实锤);它还常驻 3 个节拍对齐
            # 的音频线程,把内核负载均值抬高约 3。
            # 确需原厂 SIP 服务时放开关文件 nx5_conf/intercom/sipservice_on 再重启:仍先于
            # 显示 Owner 启动、等它做完媒体重置(实测 2s 内打开 /dev/vo),且每次开机只启一次。
            if [ -f /data/nx5_conf/intercom/sipservice_on ] && [ -x /system/user/bin/sipservice ] \
               && ! pidof sipservice >/dev/null 2>&1; then
                mkdir -p /tmp/run
                ( cd /tmp/run; touch sipservice.pid
                  LD_LIBRARY_PATH=/system/user/lib/p3_sip:/system/user/lib/p3:/system/user/lib:/system/lib
                  export LD_LIBRARY_PATH
                  # 输出绝不进 tmpfs:通话后其音频线程每分钟刷数十 MB,曾灌满 /tmp 触发
                  # 内核 OOM 反复杀 GUI(2026-11-25)。语音诊断看 baresip/helper 日志。
                  exec setsid /system/user/bin/sipservice >/dev/null 2>&1 </dev/null ) &
                i=0
                while [ $i -lt 50 ]; do
                    SP=$(pidof sipservice 2>/dev/null)
                    case "$SP" in ''|*[!0-9]*) break ;; esac
                    ls -l /proc/${SP%% *}/fd 2>/dev/null | grep -q "/dev/vo" && break
                    usleep 200000 2>/dev/null || sleep 1
                    i=$((i+1))
                done
                sleep 2
                echo "[start_app] sipservice up (pid=$(pidof sipservice 2>/dev/null)) before display" >>/data/nx5gui_live.log
            fi
            # The vendor bootstrap temporarily enables VO and closes it on exit.
            # Request darkness before it touches the LCD, not just before nx5vo.
            if [ -x /data/nx5_vdec_helper ]; then
                if [ -x /data/bin/nx5blpub ]; then
                    /data/bin/nx5blpub 0 >>/data/nx5gui_live.log 2>&1
                    usleep 200000 2>/dev/null || sleep 1
                fi
                /data/nx5_vdec_helper --bootstrap >>/data/nx5gui_live.log 2>&1
            fi
            # fix263:硬解常驻守护(GUI 内存紧张,fork/posix_spawn 会 ENOMEM)。
            # 只等请求文件 /tmp/camreq,不占解码资源;GUI 退出它也留着。
            if [ -x /data/nx5_vdec_helper ]; then
                DP=$(cat /tmp/nx5cam_d.pid 2>/dev/null)
                if [ -z "$DP" ] || ! kill -0 "$DP" 2>/dev/null; then
                    ( nohup /data/nx5_vdec_helper --daemon >>/data/nx5gui_live.log 2>&1 & )
                fi
            fi
            # 语音对讲进程看护(每次开机只起一个看护;看护循环重入不会再起第二个)。
            #   总开关 = 网页「系统设置 → 语音对讲」的开关,决定文件 intercom_on(内容 1/0)。
            #   关闭 → 对讲相关进程不开机启动,运行中的也会被结束;开启 → 10 秒内拉起。
            #   文件不存在 = 沿用这台设备此前的状态(与固件 ic_intercom_enabled() 同款判定):
            #   已配置 SIP 模式,或装着 WebRTC helper 且带目标表 → 启用;全新安装 → 未启用。
            #   栈的选择不变:mode 文件为 sip 用 Baresip + nx5sip_helper,否则用 WebRTC
            #   helper;两者不能同时跑(抢 /dev/acw-0)。
            #   ha_link_guard 复位 eth0 后会结束 SIP 栈(否则 Baresip 丢失本地地址,此后
            #   呼出全部失败,2026-11-25 两台开机必现),也由这里重新拉起。
            intercom_enabled() {
                [ -f /data/nx5_conf/intercom/intercom_on ] &&
                    { grep -q '^1' /data/nx5_conf/intercom/intercom_on; return $?; }
                if [ -f /data/nx5_conf/intercom/mode ] && grep -q '^sip' /data/nx5_conf/intercom/mode; then
                    return 0
                fi
                [ -f /data/nx5_conf/intercom/targets.json ] && [ -x /data/nx5ic_helper ]
            }
            intercom_sip() {
                [ -f /data/nx5_conf/intercom/mode ] && grep -q '^sip' /data/nx5_conf/intercom/mode &&
                    [ -x /data/nx5_conf/baresip/baresip ] && [ -x /data/nx5_conf/baresip/nx5sip_helper ]
            }
            INTERCOM_KEEPER=/tmp/nx5/intercom.keeper
            if [ ! -f "$INTERCOM_KEEPER" ] && { [ -d /data/nx5_conf/baresip ] || [ -x /data/nx5ic_helper ]; }; then
                : > "$INTERCOM_KEEPER"
                if [ -x /data/nx5_logd ]; then SIP_OUT_DEVNULL=1; else SIP_OUT_DEVNULL=0; fi
                (
                    sleep 25                    # 等网络/DHCP 与显示稳定
                    while :; do
                        if intercom_enabled; then
                            if intercom_sip; then
                                if ! pidof ld-linux.so.3 >/dev/null 2>&1; then
                                    cd /data/nx5_conf/baresip
                                    if [ "$SIP_OUT_DEVNULL" = 1 ]; then
                                        setsid /data/nx5_logd --capture sip -- /data/nx5nss/runtime/ld-linux.so.3 --library-path /data/nx5nss/runtime:/system/user/lib ./baresip -f /data/nx5_conf/baresip >/dev/null 2>&1 </dev/null &
                                    else
                                        setsid /data/nx5nss/runtime/ld-linux.so.3 --library-path /data/nx5nss/runtime:/system/user/lib ./baresip -f /data/nx5_conf/baresip >>/data/baresip.log 2>&1 </dev/null &
                                    fi
                                    sleep 3                 # 先让 Baresip 起来,helper 再连它的控制口
                                fi
                                if ! pidof nx5sip_helper >/dev/null 2>&1; then
                                    cd /data/nx5_conf/baresip
                                    if [ "$SIP_OUT_DEVNULL" = 1 ]; then
                                        setsid /data/nx5_logd --capture sip -- ./nx5sip_helper >/dev/null 2>&1 </dev/null &
                                    else
                                        setsid ./nx5sip_helper >>/data/nx5sip_helper.log 2>&1 </dev/null &
                                    fi
                                fi
                            elif ! pidof nx5ic_helper >/dev/null 2>&1; then
                                cd /data && setsid /data/nx5ic_helper >>/data/nx5ic_helper.log 2>&1 </dev/null &
                            fi
                        else
                            # 总开关关闭:结束全部对讲进程(下一轮起不再拉起)
                            for p in $(pidof ld-linux.so.3 nx5sip_helper nx5ic_helper 2>/dev/null); do
                                kill "$p" 2>/dev/null
                            done
                        fi
                        sleep 10
                    done
                ) &
            fi
            # 白斑终案(2026-11-10):常驻显示 Owner(nx5vo)持有 VO 会话+fb0
            # 跨 GUI 重启——GUI 死亡不触发驱动最后关闭,面板持续扫描、画面冻结,
            # GUI 拉起后无缝接管。Owner 自带监督(退避重启/连续失败压黑节流/
            # 控制口背光交接),此处只看护 Owner 本身。
            NX5_ENABLE_LOCAL_ACTIONS=1 NX5_ENABLE_LOCAL_SHELL=1 LD_LIBRARY_PATH=/data/nx5nss NX5_CIVET_BIND=0.0.0.0 NX5_CIVET_ALLOW_OPEN=1 NX5TS_DBG=1 nohup ./nx5vo ./nx5gui /data/nx5_conf/intercom/home_layout.json /dev/fb0 /dev/input/event0 >> /data/nx5gui_live.log 2>&1 &
            # 蓝牙代理:开关标志 nx5_conf/bt_on
            [ -x /data/btproxy.sh ] && [ -f /data/nx5_conf/intercom/bt_on ] && (sleep 8; /data/bin/nx5-log-run ble -- /data/btproxy.sh >/dev/null 2>&1 &)
            # Zigbee 网关
            [ -x /data/zbbridge.sh ] && [ -f /data/nx5_conf/intercom/zb_on ] && (sleep 20; setsid /data/bin/nx5-log-run zigbee -- sh /data/zbbridge.sh reset >/dev/null 2>&1 &)
            # 看护 Owner:GUI 死亡由 Owner 秒级拉起(画面冻结,无需背光动作);
            # Owner 本身死亡→GUI 仍持有继承引用(显示链活着)→重启 Owner 接管
            #
            # 稳态零 fork(2026-11-26):原来每 0.3s 一轮,每轮 date(心跳)+usleep+ps|grep|grep|awk
            # +readlink 约 9 个进程,这一段就是设备每秒约 45 次进程创建的大头。现在:
            #   - 等待用内建 read -t 1 等一个永远没有数据的 FIFO(本机 busybox ash 的 read -t
            #     只认整数秒,所以节拍是 1s;Owner 死亡最迟 1 秒后发现);
            #   - 存活用内建 [ -d /proc/$VP ];每 10 轮才 readlink 核对一次可执行文件
            #     (防 pid 被别的进程复用),心跳 hb 也每 10 轮写一次(单实例判定窗口 20s)。
            STABLE=0; TICKS=0; SEEN=0; VP=""
            owner_find() {
                p=$(pidof nx5vo 2>/dev/null); p=${p%% *}
                case "$p" in ''|*[!0-9]*) return 1;; esac
                VP=$p; return 0
            }
            owner_is_ours() {
                case "$(readlink /proc/$VP/exe 2>/dev/null)" in /data/nx5vo|"/data/nx5vo (deleted)") return 0;; esac
                return 1
            }
            KFIFO=/tmp/start_app.tick
            [ -p "$KFIFO" ] || mkfifo "$KFIFO" 2>/dev/null
            # ★busybox ash:exec 重定向失败会让整个脚本退出。先在子 shell 里试开,成功才开到自己身上;
            # FIFO 建不出来就退回 sleep 1(每秒一个进程,但仍远少于原来)。
            KTICK=sleep
            if [ -p "$KFIFO" ] && ( exec 9<>"$KFIFO" ) 2>/dev/null; then
                exec 9<>"$KFIFO"
                KTICK=fifo
            fi
            ktick() { if [ "$KTICK" = fifo ]; then read -t 1 _ <&9; else sleep 1; fi; }
            while :; do
                ktick
                TICKS=$((TICKS+1))
                [ $((TICKS % 10)) -eq 1 ] && hb
                OK=0
                if [ -n "$VP" ] && [ -d "/proc/$VP" ]; then
                    OK=1
                    [ $((TICKS % 10)) -eq 0 ] && {
                        owner_is_ours || OK=0
                        # 硬编 helper 中途死亡后原无人拉起:投屏永久「等待设备画面」、
                        # 摄像头不可用,只能重启面板(2026-11-26)。跟 Owner 同拍检查,
                        # 内建 read 读 pid 文件、kill -0 查活,稳态零新增 fork。
                        if [ -x /data/nx5_vdec_helper ]; then
                            DP=""
                            [ -r /tmp/nx5cam_d.pid ] && read DP < /tmp/nx5cam_d.pid 2>/dev/null
                            if [ -z "$DP" ] || ! kill -0 "$DP" 2>/dev/null; then
                                ( nohup /data/nx5_vdec_helper --daemon >>/data/nx5gui_live.log 2>&1 & )
                            fi
                        fi
                    }
                fi
                if [ "$OK" = 0 ]; then
                    # 记着的 pid 没了或可疑:按名字重找(可能是别的执行体刚拉起的新实例)
                    if owner_find && owner_is_ours; then OK=1; fi
                fi
                if [ "$OK" = 1 ]; then
                    SEEN=1
                    STABLE=$((STABLE+1))
                    if [ $STABLE -gt 60 ]; then TRIES=0; STABLE=0; fi   # 稳定 60s 后重置重试计数
                    continue
                fi
                # 刚拉起还没见过:最多再等 6 轮让它出现,别把启动慢当成死亡
                if [ "$SEEN" = 0 ] && [ $TICKS -lt 6 ]; then continue; fi
                STABLE=0
                exec 9>&- 2>/dev/null
                # 旧安装包把背光直发工具装在 /data 顶层,而显示 Owner 和本脚本用的都是
                # /data/bin/nx5blpub(2026-11-27 起安装器直接装到 bin/,由它管理)。
                # 只在目标缺失/为空时,经临时文件 + mv 原子补上。
                # ★原先是无条件  cp -f /data/nx5blpub /data/bin/nx5blpub  ——非原子覆盖:
                #   reboot 时 Owner 先退出,看护循环恰好在关机前的最后一拍走进本分支,cp 先把
                #   目标截成 0 字节,系统随即关机把拷贝杀在半路,/data/bin/nx5blpub 留成 0 字节,
                #   下次开机 Owner 点亮失败(status 32512),"背光常亮"整个失效(206 实测)。
                if [ -s /data/nx5blpub ] && [ ! -s /data/bin/nx5blpub ]; then
                    mkdir -p /data/bin
                    cp /data/nx5blpub "/data/bin/nx5blpub.migrating.$$" && chmod 755 "/data/bin/nx5blpub.migrating.$$" && mv -f "/data/bin/nx5blpub.migrating.$$" /data/bin/nx5blpub
                fi
                echo "[start_app] nx5vo died (GUI keeps display), restarting owner"
                NX5_ENABLE_LOCAL_ACTIONS=1 NX5_ENABLE_LOCAL_SHELL=1 LD_LIBRARY_PATH=/data/nx5nss NX5_CIVET_BIND=0.0.0.0 NX5_CIVET_ALLOW_OPEN=1 NX5TS_DBG=1 nohup ./nx5vo ./nx5gui /data/nx5_conf/intercom/home_layout.json /dev/fb0 /dev/input/event0 >> /data/nx5gui_live.log 2>&1 &
                break
            done
            exec 9>&- 2>/dev/null
            TRIES=$((TRIES+1))
        done
        echo "[start_app] direct boot keeper exited (gui tries=$TRIES)"
        exit 0
    fi

    # ============ 常规接管模式(v6 流程) ============
    # ---- 直启:垫片 bind mount(旧方案保留但不再默认) ----
    if [ -n "$NX5_KILL_TAKEOVER" ] || [ -f /data/productionTest ]; then :; fi

    # ---- 等原厂 aciga_lvgl 出现(最多 120s) ----
    i=0
    while [ $i -lt 24 ]; do
        hb
        VP=""
        for p in $(ps | grep aciga_lvgl | grep -v grep | awk '{print $1}'); do
            case "$(readlink /proc/$p/exe 2>/dev/null)" in /system/*) VP="$VP $p";; esac
        done
        [ -n "$VP" ] && break
        sleep 5
        i=$((i+1))
    done

    # ---- 等面板点亮 ----
    j=0
    while [ $j -lt 40 ]; do
        hb
        D=$(cat /sys/class/pwm/pwmchip0/pwm0/duty_cycle 2>/dev/null)
        case "$D" in ''|0) sleep 1; j=$((j+1));; *) break;; esac
    done
    sleep 5

    # ---- kill-接管(原厂点亮使命完成,杀掉;GUI 重开 fb0 复点) ----
    if [ -n "$NX5_KILL_TAKEOVER" ]; then
        for p in $(ps | grep aciga_lvgl | grep -v grep | awk '{print $1}'); do
            case "$(readlink /proc/$p/exe 2>/dev/null)" in /system/*) kill -9 $p 2>/dev/null; echo "[start_app] kill-takeover: vendor $p killed";; esac
        done
        sleep 2
    fi

    # ---- 启动我们的 GUI + 崩溃自动重启(≤3 次) ----
    TRIES=0
    while [ $TRIES -lt 3 ]; do
        hb
        cd /data
        export PATH=$PATH:/system/bin:/system/user/bin
        export LD_LIBRARY_PATH=/system/user/lib:/system/lib
        NX5_ENABLE_LOCAL_ACTIONS=1 NX5_ENABLE_LOCAL_SHELL=1 LD_LIBRARY_PATH=/data/nx5nss NX5_CIVET_BIND=0.0.0.0 NX5_CIVET_ALLOW_OPEN=1 NX5TS_DBG=1 nohup ./nx5gui /data/nx5_conf/intercom/home_layout.json /dev/fb0 /dev/input/event0 >> /data/nx5gui_live.log 2>&1 &
        [ -x /data/btproxy.sh ] && [ -f /data/nx5_conf/intercom/bt_on ] && (sleep 8; /data/bin/nx5-log-run ble -- /data/btproxy.sh >/dev/null 2>&1 &)
        [ -x /data/zbbridge.sh ] && [ -f /data/nx5_conf/intercom/zb_on ] && (sleep 20; setsid /data/bin/nx5-log-run zigbee -- sh /data/zbbridge.sh reset >/dev/null 2>&1 &)
        sleep 5
        STABLE=0
        k=0
        while [ $k -lt 4320 ]; do
            hb
            ALIVE=""
            for p in $(ps | grep nx5gui | grep -v grep | awk '{print $1}'); do
                case "$(readlink /proc/$p/exe 2>/dev/null)" in /data/*) ALIVE=1;; esac
            done
            [ -z "$ALIVE" ] && break
            if [ -n "$NX5_KILL_TAKEOVER" ] && [ $((k % 12)) -eq 0 ]; then
                for p in $(ps | grep aciga_lvgl | grep -v grep | awk '{print $1}'); do
                    case "$(readlink /proc/$p/exe 2>/dev/null)" in /system/*) kill -9 $p 2>/dev/null;; esac
                done
                grep -q "shim_lvgl" /proc/mounts 2>/dev/null || \
                    mount --bind /data/shim_lvgl /system/user/bin/aciga_lvgl 2>/dev/null
            fi
            sleep 5
            k=$((k+1))
        done
        if [ -n "$NX5_DIRECT_BOOT" ]; then
            TRIES=$((TRIES+1)); continue
        fi
        for p in $(ps | grep aciga_lvgl | grep -v grep | awk '{print $1}'); do
            kill -CONT $p 2>/dev/null
        done
        sleep 15
        for p in $(ps | grep aciga_lvgl | grep -v grep | awk '{print $1}'); do
            case "$(readlink /proc/$p/exe 2>/dev/null)" in /system/*) kill -STOP $p 2>/dev/null;; esac
        done
        TRIES=$((TRIES+1))
    done
    for p in $(ps | grep aciga_lvgl | grep -v grep | awk '{print $1}'); do
        kill -CONT $p 2>/dev/null
    done
) &
exit 0
