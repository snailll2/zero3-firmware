#!/bin/sh
# Runs once after reboot. Restore the preceding runtime if its replacement cannot boot.
set -eu
ROOT=${NX5_HEALTH_ROOT:-/data}
DIR="$ROOT/nx5_ota"
[ -f "$DIR/pending" ] || exit 0
LOCK=${NX5_HEALTH_LOCK:-/tmp/nx5-ota-health.lock}
mkdir "$LOCK" 2>/dev/null || exit 0
trap 'rmdir "$LOCK" 2>/dev/null || :' EXIT
. "$DIR/pending"
CURL="$ROOT/nx5_conf/intercom/curl"
write_result() {
 printf '{"job_id":"%s","version":"%s","phase":"%s","status":"%s","progress":%s,"error":"%s"}\n' "$JOB" "$VERSION" "$1" "$2" "$3" "$4" > "$DIR/result.json.new"
 mv -f "$DIR/result.json.new" "$DIR/result.json"; sync
}
write_result health_check RUNNING 95 ''
i=0
while [ "$i" -lt "${NX5_HEALTH_TRIES:-30}" ]; do
 if "$CURL" -fsS --max-time 2 http://127.0.0.1:8080/api/version 2>/dev/null | grep -Fq "\"version\":\"$VERSION\""; then
   write_result complete SUCCESS 100 ''
   rm -f "$DIR/pending" "$DIR/ota.tar" "$DIR/ota_upload.envelope" "$DIR/ota_try.tar" "$DIR/owner-boot"
   if [ -x "$ROOT/storage_guard.sh" ]; then NX5_STORAGE_ROOT="$ROOT" sh "$ROOT/storage_guard.sh" --confirmed "$BACKUP" || echo '[ota] backup pruning deferred';fi
   echo "[ota] health passed version=$VERSION job=$JOB"; exit 0
 fi
 i=$((i+1)); sleep "${NX5_HEALTH_SLEEP:-3}"
done
# This file and its relative destinations were created by the verified installer.
case "$BACKUP" in "$ROOT"/deployment-backups/*) ;; *) write_result failed FAILED 0 '回退目录无效'; exit 1;; esac
while IFS= read -r rel; do
 case "$rel" in /*|*../*) exit 1;; esac
 if [ -f "$BACKUP/files/$rel" ]; then
   ln "$BACKUP/files/$rel" "$ROOT/$rel.rollback" 2>/dev/null || cp -p "$BACKUP/files/$rel" "$ROOT/$rel.rollback"; mv -f "$ROOT/$rel.rollback" "$ROOT/$rel"
 else rm -f "$ROOT/$rel"; fi
done < "$BACKUP/changed-files"
write_result rolled_back FAILED 0 '升级后的版本未通过启动检查，已回退'
rm -f "$DIR/pending" "$DIR/ota.tar" "$DIR/ota_upload.envelope" "$DIR/ota_try.tar" "$DIR/owner-boot"
sync
echo "[ota] rolled back version=$VERSION job=$JOB"
[ "$ROOT" != /data ] || { sleep 1; reboot; }
