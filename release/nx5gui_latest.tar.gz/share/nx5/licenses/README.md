# ARM runtime deployment inputs

`curl` is built from this repository's curl 8.11.1 and mbedTLS sources with
`tools/build_runtime_curl.sh`, using an ARM soft-float musl 1.2.5 static runtime built from the included
source archive. This keeps curl DNS/TLS independent of glibc dlopen/NSS. It is a standalone static executable supporting
HTTP/HTTPS and stdin request configuration. No credentials are compiled in.

`nx5nss` contains the glibc 2.31 DNS/files NSS modules and every ELF DT_NEEDED
runtime dependency (libresolv.so.2, libc.so.6, ld-linux.so.3), exported from
that same Debian bullseye cross-toolchain. Files are regular dereferenced copies.

The public btproxy/zbbridge/nx5blpub executables were migrated from the
workspace deployment inputs; no per-device configuration is included.

License notices: CURL-COPYING, MBEDTLS-LICENSE, MUSL-COPYRIGHT and GLIBC-COPYRIGHT.
These are application dependencies on the stock NX5 system, not kernel modules.

The glibc companion libc/loader/resolver files are installed under
`/data/nx5nss/runtime`, outside the general LD_LIBRARY_PATH. Putting them at the
NSS root breaks stock dynamically linked launch commands on the device.
