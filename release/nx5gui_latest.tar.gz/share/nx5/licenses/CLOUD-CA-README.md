# 米家云 MQTT 公共 CA

`mijia_cloud_ca.crt` 为 curl 项目从 Mozilla 信任库提取的公共 CA 集合，不含账号或客户端私钥。

来源：https://curl.se/docs/caextract.html
下载：https://curl.se/ca/cacert.pem
校验：https://curl.se/ca/cacert.pem.sha256
许可：MPL 2.0，见随附 MPL-2.0.txt。源数据与转换工具链接见上述来源页。

安装到 `/data/nx5_conf/intercom/mijia_cloud_ca.crt`，与本地中枢使用的 `mijia_ca.cert` 分开。更新时必须核对官方校验和并同步 cloud-ca.json。
