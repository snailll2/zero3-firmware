#!/bin/sh
# ==============================================================================
# 零洞 Zero3 智能中控 (NX5, 1024x600) - Custom GUI Installer
# 参照 mopad_lite_custom_gui/install.sh 结构,适配 NX5 接管形态:
#   - 便携 curl 获取(设备 busybox wget 无 https)→ 多镜像下载 release 包
#   - 备份用户配置(/data/nx5_conf/intercom/*.json)
#   - 精确替换 /data/aciga_lvgl(按 exe 匹配杀进程,原厂 /system 冻结共存不动)
#   - 零重启热启动(keeper 保持接管;curl 持久化供后续 OTA 直连)
# 更新地址: 本仓库 snailll2/zero3-firmware
# ==============================================================================

TARGET_BIN="/data/aciga_lvgl"
CONF_DIR="/data/nx5_conf/intercom"
mkdir -p "$CONF_DIR"
TAR_NAME="nx5gui_latest.tar.gz"
URL_LIST="
https://ghfast.top/https://raw.githubusercontent.com/snailll2/zero3-firmware/main/release/${TAR_NAME}
https://cdn.jsdelivr.net/gh/snailll2/zero3-firmware@main/release/${TAR_NAME}
https://raw.githubusercontent.com/snailll2/zero3-firmware/main/release/${TAR_NAME}
"

echo "========================================================"
echo "   零洞 Zero3 智能中控固件安装器 (NX5)"
echo "========================================================"

# ---------------------------------------------------------------- 1. HTTPS curl
CURL_EXEC=""
for p in "$CONF_DIR/curl" /data/curl /tmp/curl /usr/bin/curl; do
    [ -x "$p" ] && CURL_EXEC="$p" && break
done
[ -n "$CURL_EXEC" ] || { command -v curl >/dev/null 2>&1 && CURL_EXEC="curl"; }
if [ -z "$CURL_EXEC" ]; then
    echo "[*] 无 HTTPS 能力(busybox wget 不支持),经 HTTP 获取便携 curl..."
    wget -O /tmp/curl "http://master.dl.sourceforge.net/project/aqarahub/binutils/curl?viasf=1" 2>/dev/null || true
    chmod a+x /tmp/curl 2>/dev/null || true
    [ -x /tmp/curl ] && CURL_EXEC="/tmp/curl"
fi
if [ -z "$CURL_EXEC" ]; then
    echo "[-] 获取 curl 失败。手动执行:"
    echo "    wget -O /tmp/curl http://master.dl.sourceforge.net/project/aqarahub/binutils/curl?viasf=1 && chmod +x /tmp/curl"
    exit 1
fi
echo "[+] curl: $CURL_EXEC"

# ---------------------------------------------------------------- 2. /tmp 空间
AVAIL=$(df -m /tmp 2>/dev/null | awk '$NF=="/tmp"{print $4}')
case "$AVAIL" in ''|*[!0-9]*) AVAIL=16 ;; esac
if [ "$AVAIL" -lt 12 ]; then
    echo "[*] /tmp 剩余 ${AVAIL}M,清理残留..."
    rm -f /tmp/ota.img /tmp/ota.md5.actual /tmp/ota_ver.json /tmp/ota_flash.log 2>/dev/null
    AVAIL=$(df -m /tmp 2>/dev/null | awk '$NF=="/tmp"{print $4}')
fi
if [ -z "$AVAIL" ] || [ "$AVAIL" -lt 12 ]; then
    echo "[-] /tmp 空间不足(需 >=12M, 现 ${AVAIL}M),无法安全下载。"
    exit 1
fi
echo "[+] /tmp 可用 ${AVAIL}M"

# ---------------------------------------------------------------- 3. 备份用户配置
BACKUP_DIR="/data/nx5_conf_backup_$(date +%s)"
HAS_CFG=0
for f in "$CONF_DIR"/*.json; do
    [ -f "$f" ] && HAS_CFG=1 && break
done
if [ "$HAS_CFG" -eq 1 ]; then
    echo "[1/6] 备份用户配置 -> $BACKUP_DIR"
    mkdir -p "$BACKUP_DIR"
    cp -f "$CONF_DIR"/*.json "$BACKUP_DIR/" 2>/dev/null || true
else
    echo "[1/6] 无既有配置,跳过备份"
fi

# ---------------------------------------------------------------- 4. 下载 release 包(先验包再动系统)
echo "[2/6] 检查 release 包..."
LOCAL_TAR="/tmp/$TAR_NAME"
DOWNLOAD_OK=0
# 离线口:PC 下载 tar.gz 推到设备 /tmp/$TAR_NAME 后再跑本脚本,直接跳过下载
if [ -s "$LOCAL_TAR" ] && tar -tzf "$LOCAL_TAR" >/dev/null 2>&1; then
    SZ=$(wc -c < "$LOCAL_TAR")
    if [ "$SZ" -gt 2000000 ]; then
        DOWNLOAD_OK=1
        echo "[+] 使用已存在的 /tmp/$TAR_NAME ($SZ bytes,离线模式)"
    fi
fi
[ "$DOWNLOAD_OK" -eq 1 ] || for U in $URL_LIST; do
    echo "[*] 尝试源: $U"
    rm -f "$LOCAL_TAR"
    if $CURL_EXEC -skfL --connect-timeout 10 -m 300 -o "$LOCAL_TAR" "$U" && [ -s "$LOCAL_TAR" ]; then
        SZ=$(wc -c < "$LOCAL_TAR")
        if [ "$SZ" -gt 2000000 ] && tar -tzf "$LOCAL_TAR" >/dev/null 2>&1; then
            DOWNLOAD_OK=1
            echo "[+] 下载并校验成功 ($SZ bytes)"
            break
        fi
    fi
done
if [ "$DOWNLOAD_OK" -ne 1 ]; then
    echo "[-] 所有镜像均无法取得有效 release 包。"
    exit 1
fi

# ------------------------------------------------- 4.5 防镜像缓存旧包(2026-10-22 实测坑)
# ghfast/jsdelivr 会把 release 资产缓存数小时,曾把 1.0.118 旧包当 latest 发给设备。
# 解包读 tar 内 version.json,与 raw 源 version.json 比对;旧包一律中止(离线口可 FORCE=1 跳过)。
if [ "$DOWNLOAD_OK" -eq 1 ] && [ -z "$FORCE" ]; then
    "$CURL_EXEC" -skfL -m 10 "https://raw.githubusercontent.com/snailll2/zero3-firmware/main/version.json" -o /tmp/inst_ref_ver.json 2>/dev/null || true
    REF_VER=$(grep -o '"version"[^,]*' /tmp/inst_ref_ver.json 2>/dev/null | head -1 | cut -d'"' -f4)
    REF_SIZE=$(grep -o '"size"[^,]*' /tmp/inst_ref_ver.json 2>/dev/null | head -1 | grep -o '[0-9]*')
    TAR_SIZE_CK=$SZ
    echo "[*] 包版本: $TAR_VER / 官方最新: ${REF_VER:-未知}"
    if [ -n "$REF_SIZE" ] && [ -n "$TAR_SIZE_CK" ] && [ "$TAR_SIZE_CK" != "$REF_SIZE" ]; then
        echo "[-] 镜像缓存了旧包(大小 $TAR_SIZE_CK ≠ 官方 $REF_SIZE),已中止以防降级。"
        echo "    请稍后重试(缓存约 5-10 分钟过期),或 FORCE=1 强制安装 / 离线模式。"
        exit 1
    fi
fi

# ---------------------------------------------------------------- 5. 替换固件(精确 kill,原厂不动)
echo "[3/6] 停止现有 GUI(按 exe 精确匹配,原厂冻结共存不受影响)..."
for p in $(ls /proc 2>/dev/null | grep -E '^[0-9]+$'); do
    e=$(readlink /proc/$p/exe 2>/dev/null)
    [ "$e" = "$TARGET_BIN" ] && kill -9 $p 2>/dev/null
done
sleep 2

echo "[3.5/6] 固化开机自启(接管脚本 → /data/bin,Sinit 钩子开机执行)..."
mkdir -p /data/bin
if [ -f /data/bin/start_app.sh ]; then
    cp -f /data/bin/start_app.sh /data/bin/start_app.sh.bak 2>/dev/null || true
fi
tar -zxvf "$LOCAL_TAR" -C /data > /tmp/install_tar.log 2>&1
if [ ! -x /data/nx5gui ]; then
    echo "[-] 解包断言失败(nx5gui 缺失),中止(旧固件仍在)..."
    rm -f "$LOCAL_TAR"
    exit 1
fi
# 还原用户配置(安装包内不带配置,避免覆盖)
if [ -d "$BACKUP_DIR" ]; then
    echo "[*] 还原用户配置..."
    cp -f "$BACKUP_DIR"/*.json "$CONF_DIR/" 2>/dev/null || true
    rm -rf "$BACKUP_DIR"
fi
mv -f /data/nx5gui "$TARGET_BIN" && chmod +x "$TARGET_BIN" && sync
# 接管脚本落位(幂等;已有 start_app.sh.bak 时不覆盖用户备份)
if [ -f /data/start_app.sh ]; then
    cp -f /data/start_app.sh /data/bin/start_app.sh && chmod +x /data/bin/start_app.sh
    [ -f /data/bin/data_app.sh ] || { printf '# dummy: Sinit 检查 data_app.sh 存在但运行 start_app.sh\n' > /data/bin/data_app.sh; chmod +x /data/bin/data_app.sh; }
    rm -f /data/start_app.sh
fi
rm -f "$LOCAL_TAR"

# curl 持久化(后续 OTA 直连快速通道)
if [ -x /tmp/curl ] && [ ! -x "$CONF_DIR/curl" ]; then
    cp -f /tmp/curl "$CONF_DIR/curl" 2>/dev/null && chmod +x "$CONF_DIR/curl" 2>/dev/null
fi

# ---------------------------------------------------------------- 6. 热启动 + 验证
echo "[5/6] 热启动 GUI..."
( cd /data && nohup /data/aciga_lvgl >/data/nx5gui.out 2>&1 & )
echo "[6/6] 验证..."
sleep 5
GUI_OK=0
for p in $(ls /proc 2>/dev/null | grep -E '^[0-9]+$'); do
    e=$(readlink /proc/$p/exe 2>/dev/null)
    [ "$e" = "$TARGET_BIN" ] && GUI_OK=1 && break
done

DEV_IP=$(ip -4 addr show eth0 2>/dev/null | grep -o 'inet [0-9.]*' | cut -d' ' -f2)
[ -z "$DEV_IP" ] && DEV_IP=$(ip -4 addr show wlan0 2>/dev/null | grep -o 'inet [0-9.]*' | cut -d' ' -f2)
[ -z "$DEV_IP" ] && DEV_IP=$(ifconfig eth0 2>/dev/null | awk '/inet addr/{print $2}' | cut -d: -f2)
[ -z "$DEV_IP" ] && DEV_IP="<面板IP>"

if [ "$GUI_OK" -eq 1 ]; then
    echo "========================================================"
    echo " [SUCCESS] 零洞 Zero3 固件安装成功并已运行!"
    echo " -> 屏幕已接管(原厂冻结共存,重启自动恢复)"
    echo " -> Web 控制台: http://${DEV_IP}:8080/"
    echo " -> 授权: 设置页查看机器码/激活状态"
    echo "========================================================"
else
    echo "[-] GUI 未能立即拉起,查看 /data/nx5gui.out 尾部:"
    tail -n 8 /data/nx5gui.out 2>/dev/null
    echo "[*] /data/bin keeper 会自动重试拉起;5 秒后复查。"
    sleep 5
    for p in $(ls /proc 2>/dev/null | grep -E '^[0-9]+$'); do
        e=$(readlink /proc/$p/exe 2>/dev/null)
        [ "$e" = "$TARGET_BIN" ] && echo "[+] keeper 已拉起,安装完成。" && exit 0
    done
    exit 1
fi
