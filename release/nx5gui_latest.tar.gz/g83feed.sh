#!/bin/sh
# g83feed:外部硬看门狗 GPIO83 喂狗(500ms 翻转,复刻原厂 2Hz 语义)
# 单实例:目录锁 + pid 存活检测;旧实例退出后新实例可接管。
# 与 GUI 的 gpio83_feed_thread 协作:GUI 每秒写 /tmp/gui_feed_ts(内容=当时的 epoch 秒);
# 心跳新鲜时脚本不碰 GPIO,避免两个执行体交叉写同一根线。
#
# 让位判定(2026-11-26 改):原来每 0.2s fork 一次 `cat` + `date` + `sleep`,GUI 喂狗正常、
# 脚本整轮都在让位时也照跑(约 15 个进程/秒,是设备进程创建的头号来源)。现在:
#   - 心跳用内建 read 读文件,只比对"内容有没有变"(GUI 每秒写一个新值),不再要 date;
#     连续 STALE 轮没变化才算过期——与原来"2 秒内更新过"等价,而且不受校时跳变影响
#     (原来开机校时后 now 突然超前,脚本会误判过期、和 GUI 同时喂约 1 秒);
#   - 等待用内建 read -t 1 等一个永远没有数据的 FIFO,不 fork(FIFO 建不出来才退回 sleep)。
# 外部硬看狗的实际超时约 15 分钟(fix133:919s),接管从 2 秒放宽到 3~4 秒没有影响。
LOCK=/tmp/g83feed.lock
if ! mkdir "$LOCK" 2>/dev/null; then
  P=$(cat "$LOCK/pid" 2>/dev/null)
  if [ -n "$P" ] && [ -d "/proc/$P" ]; then exit 0; fi
  rm -rf "$LOCK"; mkdir "$LOCK" 2>/dev/null || exit 0
fi
echo $$ > "$LOCK/pid"
# 收到 INT/TERM 干净退出并释放锁。原写法 trap '…' EXIT INT TERM 只删锁、不退出:
# 被终止的旧实例会继续跑(2026-11-26 换新版脚本时实测新旧两个实例并存)。
trap 'rm -rf "$LOCK"' EXIT
trap 'exit 0' INT TERM

STALE=3                                   # 连续多少轮(每轮 1s)心跳没变才认为 GUI 停喂
FIFO=/tmp/g83feed.tick
[ -p "$FIFO" ] || mkfifo "$FIFO" 2>/dev/null
TICKMODE=sleep
# ★busybox ash:exec 重定向失败会让整个脚本退出(本机实测 rc=2)。先在子 shell 里试开,
# 成功才开到自己身上;FIFO 建不出来就退回 sleep 1。
if [ -p "$FIFO" ] && ( exec 3<>"$FIFO" ) 2>/dev/null; then
  exec 3<>"$FIFO"
  TICKMODE=fifo
fi
tick() {                                  # 等 1 秒;本机 busybox ash 的 read -t 只认整数秒
  if [ "$TICKMODE" = fifo ]; then read -t 1 _ <&3; else sleep 1; fi
}

GPID=$(pidof nx5gui 2>/dev/null)
HB=/tmp/gui_feed_ts
last=""; same=0
while :; do
  if [ -f "$HB" ]; then
    # GUI 心跳新鲜:喂狗由 GUI 线程负责,脚本让位(否则交叉写 GPIO)
    TS=""
    read TS < "$HB" 2>/dev/null
    if [ -n "$TS" ] && [ "$TS" != "$last" ]; then last="$TS"; same=0; else same=$((same+1)); fi
    if [ "$same" -lt "$STALE" ]; then tick; continue; fi
  else
    # 旧版 GUI 没有心跳文件:只要进程在就不抢(pid 没了才重新按名字找)
    if [ -z "$GPID" ] || [ ! -d "/proc/$GPID" ]; then GPID=$(pidof nx5gui 2>/dev/null); fi
    if [ -n "$GPID" ] && [ -d "/proc/$GPID" ]; then tick; continue; fi
  fi
  if [ ! -d /sys/class/gpio/gpio83 ]; then
    echo 83 > /sys/class/gpio/export 2>/dev/null
    echo out > /sys/class/gpio/gpio83/direction 2>/dev/null
    sleep 1
  fi
  echo 1 > /sys/class/gpio/gpio83/value 2>/dev/null
  sleep 0.5 2>/dev/null || usleep 500000
  echo 0 > /sys/class/gpio/gpio83/value 2>/dev/null
  sleep 0.5 2>/dev/null || usleep 500000
done
