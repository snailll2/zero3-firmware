#!/bin/sh
# g83feed:外部硬看门狗 GPIO83 喂狗(500ms 翻转,复刻原厂 2Hz 语义)
# 单实例:目录锁 + pid 存活检测;旧实例退出后新实例可接管。
# 与 GUI 的 gpio83_feed_thread 协作:GUI 每秒写 /tmp/gui_feed_ts;
# 心跳新鲜时脚本不碰 GPIO,避免两个执行体交叉写同一根线。
LOCK=/tmp/g83feed.lock
if ! mkdir "$LOCK" 2>/dev/null; then
  P=$(cat "$LOCK/pid" 2>/dev/null)
  if [ -n "$P" ] && [ -d "/proc/$P" ]; then exit 0; fi
  rm -rf "$LOCK"; mkdir "$LOCK" 2>/dev/null || exit 0
fi
echo $$ > "$LOCK/pid"
trap 'rm -rf "$LOCK"' EXIT INT TERM

while :; do
  # GUI 心跳 <2s:喂狗由 GUI 线程负责,脚本让位(否则交叉写 GPIO)
  TS=$(cat /tmp/gui_feed_ts 2>/dev/null)
  NOW=$(date +%s)
  if [ -n "$TS" ] && [ "$NOW" -ge "$TS" ] && [ $((NOW - TS)) -le 2 ]; then
    sleep 0.2; continue
  fi
  # 旧版 GUI 没有心跳文件:只要进程在就不抢
  if [ ! -f /tmp/gui_feed_ts ] && pidof nx5gui >/dev/null 2>&1; then
    sleep 0.2; continue
  fi
  if [ ! -d /sys/class/gpio/gpio83 ]; then
    echo 83 > /sys/class/gpio/export 2>/dev/null
    echo out > /sys/class/gpio/gpio83/direction 2>/dev/null
    sleep 1
  fi
  echo 1 > /sys/class/gpio/gpio83/value 2>/dev/null
  sleep 0.5 2>/dev/null || usleep 500000
  echo 0 > /sys/class/gpio/gpio83/value 2>/dev/null
  sleep 0.5 2>/dev/null || usleep 500000
done