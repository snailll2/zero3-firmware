#!/bin/sh
# kmsg 增量流式落盘 v2(取证):跨开机追加,绝不截断历史!
# 单实例:dmesg -c 是消费式读取,多实例会互相抢走内核日志。
LOCK=/tmp/kmsglog.lock
if ! mkdir "$LOCK" 2>/dev/null; then
  P=$(cat "$LOCK/pid" 2>/dev/null)
  if [ -n "$P" ] && [ -d "/proc/$P" ]; then exit 0; fi
  rm -rf "$LOCK"; mkdir "$LOCK" 2>/dev/null || exit 0
fi
echo $$ > "$LOCK/pid"
trap 'rm -rf "$LOCK"' EXIT INT TERM

L=/data/kmsg.log
echo "===== BOOT $(date +%s) uptime=$(cut -d. -f1 /proc/uptime) =====" >> $L
while :; do
  dmesg -c >> $L 2>/dev/null
  if [ "$(wc -c < $L)" -gt 8388608 ]; then
    tail -c 4194304 $L > ${L}.t && mv -f ${L}.t $L
  fi
  sleep 1
done