#!/bin/sh
# bx2 黑匣子:5s 一拍,跨开机追加(静默复位取证)
# 单实例:目录锁 + pid 存活检测;旧实例退出后新实例可接管。
# mqtt 计数改为“按字节增量扫描”:只读上次 offset 之后的新日志,
# 不再每 5s 全量 grep 2MB 日志(多实例时曾叠加成持续 I/O)。
LOCK=/tmp/bx2.lock
if ! mkdir "$LOCK" 2>/dev/null; then
  P=$(cat "$LOCK/pid" 2>/dev/null)
  if [ -n "$P" ] && [ -d "/proc/$P" ]; then exit 0; fi
  rm -rf "$LOCK"; mkdir "$LOCK" 2>/dev/null || exit 0
fi
echo $$ > "$LOCK/pid"
trap 'rm -rf "$LOCK"' EXIT INT TERM

B=/data/bx2.log
LOG=/data/nx5gui_live.log
OFFF=/tmp/bx2.off
MCF=/tmp/bx2.mc
echo "===== BOOT $(date +%s) =====" >> $B
OFF=0; [ -f "$OFFF" ] && OFF=$(cat "$OFFF" 2>/dev/null)
MC=0;  [ -f "$MCF" ]  && MC=$(cat "$MCF" 2>/dev/null)
case "$OFF" in ''|*[!0-9]*) OFF=0;; esac
case "$MC" in ''|*[!0-9]*) MC=0;; esac
while :; do
  G=$(pidof nx5gui); TH=0
  [ -n "$G" ] && TH=$(ls /proc/$G/task 2>/dev/null | wc -l)
  G84=$(cat /sys/class/gpio/gpio84/value 2>/dev/null)
  MA=$(grep MemAvailable /proc/meminfo | awk '{print $2}')
  DUTY=$(cat /sys/class/pwm/pwmchip0/pwm0/duty_cycle 2>/dev/null)
  # 增量统计 mqtt 连接日志;日志轮转(变小)则重新从 0 开始
  SZ=$(wc -c < "$LOG" 2>/dev/null)
  case "$SZ" in ''|*[!0-9]*) SZ=0;; esac
  [ "$SZ" -lt "$OFF" ] && OFF=0
  if [ "$SZ" -gt "$OFF" ]; then
    NEW=$(tail -c +$((OFF + 1)) "$LOG" 2>/dev/null | grep -ac "mqtt. connected")
    MC=$((MC + ${NEW:-0}))
    OFF=$SZ
    echo "$OFF" > "$OFFF"; echo "$MC" > "$MCF"
  fi
  echo "$(date +%s) up=$(cut -d. -f1 /proc/uptime) gui=$G th=$TH g84=$G84 MA=$MA duty=$DUTY mqttc=$MC" >> $B
  if [ "$(wc -c < $B)" -gt 1048576 ]; then tail -c 524288 $B > ${B}.t && mv -f ${B}.t $B; fi
  sleep 5
done