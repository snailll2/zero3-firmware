#!/bin/sh
# btproxy.sh — NX5 蓝牙代理启动器(开机链/手动均可)
# 策略:面板 mesh 网络为空,mgw_bt 无用;冻结 guardian 防其重生 mgw_bt,
#       杀 mgw_bt 释放 /dev/ttyS2,启动 btproxy(配置 /data/btproxy.conf)
[ -f /data/nx5_conf/intercom/btproxy.conf ] || [ -f /data/btproxy.conf ] || { echo "btproxy.conf missing"; exit 1; }
# fix184:BLE 芯片(小易 Silabs NCP)需厂商 mgw_bt 初始化才进扫描态;mgw_bt 的
# 日志初始化要求 /tmp/log 目录存在(直启链绕过原厂脚本,缺目录则 mgw_bt 秒退,
# 芯片零广播——2026-10-28 定案)。流程:建目录→跑 mgw_bt 45s(推芯片进扫描态,
# 它会因串口超时自退,芯片保持吐流)→再杀残留起 btproxy。
mkdir -p /tmp/log
if [ -x /system/user/bin/mgw_bt ]; then
    ( /system/user/bin/mgw_bt >/dev/null 2>&1 & )
    sleep 45
    for p in $(pidof mgw_bt); do kill -9 $p 2>/dev/null; done
fi
GUARD=$(pidof aciga_guardian)
[ -n "$GUARD" ] && kill -STOP $GUARD 2>/dev/null
for p in $(pidof mgw_bt); do kill -9 $p 2>/dev/null; done
for p in $(pidof btproxy); do kill -9 $p 2>/dev/null; done
sleep 1
(setsid /data/btproxy >/dev/null 2>&1 &)
echo "btproxy started (guardian ${GUARD:-none} frozen)"
